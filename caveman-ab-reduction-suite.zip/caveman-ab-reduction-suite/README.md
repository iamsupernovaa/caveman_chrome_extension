# Caveman A/B Reduction Test Suite

This measures real output reduction:

- Caveman OFF = baseline
- Caveman Lite / Full / Ultra = comparison
- Measures words
- Measures tokens with `gpt-tokenizer`
- Calculates reduction percentage
- Saves JSON + CSV

## Install

```bash
npm install
npx playwright install chromium
```

## Start remote Chrome

PowerShell:

```powershell
taskkill /F /IM chrome.exe

& "C:\Program Files\Google\Chrome\Application\chrome.exe" `
  --remote-debugging-port=9222 `
  --user-data-dir="$env:USERPROFILE\caveman-live-chrome"
```

## Manual setup

In that Chrome:

1. Open `chatgpt.com`
2. Login
3. Load Caveman extension
4. Confirm pill works
5. Optional: open `claude.ai` and login

## Run ChatGPT only

```bash
RUN_LIVE=1 CDP_URL=http://127.0.0.1:9222 npx playwright test tests/live-ab-reduction.spec.ts -g ChatGPT --headed
```

## Run Claude only

```bash
RUN_LIVE=1 CDP_URL=http://127.0.0.1:9222 npx playwright test tests/live-ab-reduction.spec.ts -g Claude --headed
```

## Run both

```bash
RUN_LIVE=1 CDP_URL=http://127.0.0.1:9222 npx playwright test tests/live-ab-reduction.spec.ts --headed
```

## Only compare Ultra

```bash
RUN_LIVE=1 COMPARE_MODES=Ultra CDP_URL=http://127.0.0.1:9222 npx playwright test tests/live-ab-reduction.spec.ts -g ChatGPT --headed
```

## Results

```text
test-results/caveman-ab/chatgpt-ab-results.json
test-results/caveman-ab/chatgpt-ab-results.csv
test-results/caveman-ab/claude-ab-results.json
test-results/caveman-ab/claude-ab-results.csv
```
