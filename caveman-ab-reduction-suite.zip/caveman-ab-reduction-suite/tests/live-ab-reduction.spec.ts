import { test, expect } from '@playwright/test';
import { encode } from 'gpt-tokenizer';
import fs from 'node:fs';
import path from 'node:path';
import {
  Site,
  ModeLabel,
  ComparisonRow,
  getExistingPage,
  openFreshChat,
  fillPromptThenSetMode,
  clickSend,
  answerLocator,
  waitForNewAnswer,
  wordCount,
  reductionPercent,
  average
} from './helpers/liveTools';

test.setTimeout(50 * 60_000);

const runLive = process.env.RUN_LIVE === '1';
const cdpUrl = process.env.CDP_URL || 'http://127.0.0.1:9222';

const defaultPrompts = [
  'Explain AUTOSAR to a beginner with examples.',
  'Explain ROS 2 nodes, topics, services, and actions for a mobile robot.',
  'Give a practical test plan for a Chrome extension, including manual and automated testing.'
];

const prompts: string[] = process.env.LIVE_PROMPTS_JSON
  ? JSON.parse(process.env.LIVE_PROMPTS_JSON)
  : defaultPrompts;

const compareModes: ModeLabel[] = (process.env.COMPARE_MODES || 'Lite,Full,Ultra')
  .split(',')
  .map((s) => s.trim())
  .filter(Boolean) as ModeLabel[];

const minAvgTokenReduction = Number(process.env.MIN_AVG_TOKEN_REDUCTION_PERCENT || 20);
const minAvgWordReduction = Number(process.env.MIN_AVG_WORD_REDUCTION_PERCENT || 20);

function resultDir() {
  const dir = path.join(process.cwd(), 'test-results', 'caveman-ab');
  fs.mkdirSync(dir, { recursive: true });
  return dir;
}

function saveResults(site: Site, rows: ComparisonRow[]) {
  const dir = resultDir();

  const jsonPath = path.join(dir, `${site}-ab-results.json`);
  fs.writeFileSync(jsonPath, JSON.stringify(rows, null, 2), 'utf8');

  const csvPath = path.join(dir, `${site}-ab-results.csv`);

  const header = [
    'site',
    'promptIndex',
    'mode',
    'offWords',
    'modeWords',
    'wordReductionPercent',
    'offTokens',
    'modeTokens',
    'tokenReductionPercent',
    'prompt',
    'offResponse',
    'modeResponse'
  ];

  const escapeCsv = (value: unknown) => {
    const s = String(value ?? '');
    return `"${s.replace(/"/g, '""')}"`;
  };

  const csv = [
    header.join(','),
    ...rows.map((r) =>
      [
        r.site,
        r.promptIndex,
        r.mode,
        r.offWords,
        r.modeWords,
        r.wordReductionPercent,
        r.offTokens,
        r.modeTokens,
        r.tokenReductionPercent,
        r.prompt,
        r.offResponse,
        r.modeResponse
      ].map(escapeCsv).join(',')
    )
  ].join('\n');

  fs.writeFileSync(csvPath, csv, 'utf8');

  console.log(`\nSaved results:\n${jsonPath}\n${csvPath}`);
}

async function runOnePrompt(
  site: Site,
  page: any,
  prompt: string,
  promptIndex: number,
  mode: ModeLabel
) {
  await openFreshChat(page, site);

  await fillPromptThenSetMode(page, site, prompt, mode);

  const before = await answerLocator(page, site).count();

  await clickSend(page, site);

  const response = await waitForNewAnswer(page, site, before);
  const words = wordCount(response);
  const tokens = encode(response).length;

  console.log(`\n[${site}] Prompt ${promptIndex} | ${mode}`);
  console.log(`Words: ${words}`);
  console.log(`Tokens: ${tokens}`);
  console.log(response);

  return { site, promptIndex, prompt, mode, words, tokens, response };
}

async function runABForSite(site: Site, host: string) {
  const page = await getExistingPage(host, cdpUrl);

  if (!page) {
    test.skip(true, `Open ${host} manually in remote Chrome first.`);
    return;
  }

  const rows: ComparisonRow[] = [];

  for (let i = 0; i < prompts.length; i++) {
    const prompt = prompts[i];

    const off = await runOnePrompt(site, page, prompt, i + 1, 'OFF');

    for (const mode of compareModes) {
      if (!['Lite', 'Full', 'Ultra'].includes(mode)) continue;

      const active = await runOnePrompt(site, page, prompt, i + 1, mode);

      const row: ComparisonRow = {
        site,
        promptIndex: i + 1,
        prompt,
        mode,
        offWords: off.words,
        offTokens: off.tokens,
        modeWords: active.words,
        modeTokens: active.tokens,
        wordReductionPercent: reductionPercent(off.words, active.words),
        tokenReductionPercent: reductionPercent(off.tokens, active.tokens),
        offResponse: off.response,
        modeResponse: active.response
      };

      rows.push(row);

      console.log(
        `\n[${site}] Prompt ${i + 1} | OFF -> ${mode}: ` +
          `${row.tokenReductionPercent}% token reduction, ` +
          `${row.wordReductionPercent}% word reduction`
      );
    }
  }

  saveResults(site, rows);

  for (const mode of compareModes) {
    const modeRows = rows.filter((r) => r.mode === mode);
    const avgTokenReduction = average(modeRows.map((r) => r.tokenReductionPercent));
    const avgWordReduction = average(modeRows.map((r) => r.wordReductionPercent));

    console.log(`\n[${site}] OFF -> ${mode} average`);
    console.log(`Token reduction: ${avgTokenReduction}%`);
    console.log(`Word reduction: ${avgWordReduction}%`);

    expect(avgTokenReduction).toBeGreaterThanOrEqual(minAvgTokenReduction);
    expect(avgWordReduction).toBeGreaterThanOrEqual(minAvgWordReduction);
  }
}

test.describe.serial('Caveman live A/B reduction tests', () => {
  test.skip(!runLive, 'Set RUN_LIVE=1 and open logged-in remote Chrome first.');

  test('ChatGPT OFF vs Caveman modes reduction', async () => {
    await runABForSite('chatgpt', 'chatgpt.com');
  });

  test('Claude OFF vs Caveman modes reduction', async () => {
    await runABForSite('claude', 'claude.ai');
  });
});
