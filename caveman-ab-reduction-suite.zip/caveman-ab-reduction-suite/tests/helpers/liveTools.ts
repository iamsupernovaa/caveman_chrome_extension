import { expect, chromium, Page, Locator } from '@playwright/test';

export type Site = 'chatgpt' | 'claude';
export type ModeLabel = 'OFF' | 'Lite' | 'Full' | 'Ultra';

export type RunMetrics = {
  site: Site;
  promptIndex: number;
  prompt: string;
  mode: ModeLabel;
  words: number;
  tokens: number;
  response: string;
};

export type ComparisonRow = {
  site: Site;
  promptIndex: number;
  prompt: string;
  mode: ModeLabel;
  offWords: number;
  offTokens: number;
  modeWords: number;
  modeTokens: number;
  wordReductionPercent: number;
  tokenReductionPercent: number;
  offResponse: string;
  modeResponse: string;
};

export function wordCount(text: string): number {
  return text.trim().split(/\s+/).filter(Boolean).length;
}


export async function getExistingPage(host: string, cdpUrl: string): Promise<Page | null> {
  const browser = await chromium.connectOverCDP(cdpUrl);
  const pages = browser.contexts().flatMap((context) => context.pages());
  const page = pages.find((p) => p.url().includes(host));

  if (!page) return null;

  await page.bringToFront();
  await page.waitForTimeout(3000);

  const url = page.url();
  if (url.includes('login') || url.includes('challenge') || url.includes('logout')) {
    throw new Error(`${host} is not logged in. Current URL: ${url}`);
  }

  return page;
}

export async function openFreshChat(page: Page, site: Site) {
  const url = site === 'chatgpt' ? 'https://chatgpt.com/' : 'https://claude.ai/new';

  await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 60_000 });
  await page.waitForTimeout(5000);

  const current = page.url();
  if (current.includes('login') || current.includes('challenge') || current.includes('logout')) {
    throw new Error(`${site} is not logged in after navigation. Current URL: ${current}`);
  }
}

export async function getVisibleComposer(page: Page, site: Site): Promise<Locator> {
  const selector =
    site === 'chatgpt'
      ? [
          'div[contenteditable="true"]#prompt-textarea',
          'div[contenteditable="true"].ProseMirror',
          'div[contenteditable="true"]',
          'textarea:visible'
        ].join(', ')
      : [
          'div[contenteditable="true"].ProseMirror',
          'fieldset div[contenteditable="true"]',
          'div[contenteditable="true"]'
        ].join(', ');

  const composer = page.locator(selector).first();
  await expect(composer).toBeVisible({ timeout: 30_000 });
  return composer;
}

export async function setCavemanMode(page: Page, target: ModeLabel) {
  const pill = page.locator('#caveman-pill');
  await expect(pill).toBeVisible({ timeout: 30_000 });

  for (let i = 0; i < 8; i++) {
    const text = ((await pill.innerText()) || '').trim();

    if (target === 'OFF' && text.includes('OFF')) return;
    if (target !== 'OFF' && text.toLowerCase().includes(target.toLowerCase())) return;

    await pill.click();
    await page.waitForTimeout(350);
  }

  throw new Error(`Could not set Caveman mode to ${target}. Current pill: ${await pill.innerText()}`);
}

export async function fillPromptThenSetMode(page: Page, site: Site, prompt: string, mode: ModeLabel) {
  const composer = await getVisibleComposer(page, site);
  await composer.fill(prompt);

  // ChatGPT v1.4 may mount the pill only after text exists.
  await expect(page.locator('#caveman-pill')).toBeVisible({ timeout: 30_000 });

  await setCavemanMode(page, mode);
}

export async function clickSend(page: Page, site: Site) {
  const selector =
    site === 'chatgpt'
      ? 'button[data-testid="send-button"], #composer-submit-button, button[aria-label*="send" i]'
      : 'button[aria-label*="send" i]';

  const sendButton = page.locator(selector).first();
  await expect(sendButton).toBeEnabled({ timeout: 30_000 });
  await sendButton.click();
}

export function answerLocator(page: Page, site: Site): Locator {
  return site === 'chatgpt'
    ? page.locator('[data-message-author-role="assistant"]')
    : page.locator('[data-testid="message-content"], .font-claude-message');
}

export async function waitForNewAnswer(page: Page, site: Site, beforeCount: number): Promise<string> {
  const answers = answerLocator(page, site);

  await expect
    .poll(async () => await answers.count(), { timeout: 1900_000 })
    .toBeGreaterThan(beforeCount);

  const answer = answers.nth(beforeCount);
  return await waitForStableText(answer);
}

export async function waitForStableText(locator: Locator): Promise<string> {
  await expect(locator).toBeVisible({ timeout: 1900_000 });

  let last = '';
  let stableCount = 0;

  for (let i = 0; i < 180; i++) {
    const text = (await locator.innerText()).trim();

    if (text.length > 20 && text === last) {
      stableCount++;

      // stable for 10 seconds
      if (stableCount >= 5) return text;
    } else {
      stableCount = 0;
      last = text;
    }

    await new Promise((resolve) => setTimeout(resolve, 2000));
  }

  return last;
}

export function reductionPercent(base: number, reduced: number): number {
  if (base <= 0) return 0;
  return Number((((base - reduced) / base) * 100).toFixed(2));
}

export function average(values: number[]): number {
  if (!values.length) return 0;
  return Number((values.reduce((a, b) => a + b, 0) / values.length).toFixed(2));
}
